---
name: "Question"
about: Use this template if you have any questions. Preferably use the Discord (check the README).
labels: "Type: Question"
---

#### :confused: Question

> A description of what you need help with.

#### :question: Additional Information

> Anything additional goes here (screenshots, logs, etc...)
