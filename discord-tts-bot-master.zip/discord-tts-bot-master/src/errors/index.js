const InvalidProviderError = require('./InvalidProviderError');

module.exports = {
  InvalidProviderError
};
